#include "Melody.h"
#include <IBuzzer.h>

class BuzzerPlayer {
private:
  IBuzzer &_buzzer; // Reference to a buzzer object

public:
  BuzzerPlayer(IBuzzer &buzzer) : _buzzer(buzzer) {}

  void playTune(MelodyName melodyName) {
    Melody melody = getMelody(melodyName);

    for (int thisNote = 0; thisNote < melody.length; thisNote++) {
      int noteDuration = melody.notes[thisNote].duration;
      buzzer.beep(melody.notes[thisNote].frequency, noteDuration);
      int pauseBetweenNotes = noteDuration * 1.30;
      delay(pauseBetweenNotes);
      buzzer.stop(); // Stop the tone playing
    }
  }
};