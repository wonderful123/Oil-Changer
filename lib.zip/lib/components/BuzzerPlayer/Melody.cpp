#include "Melody.h"

// Define the notes for the Super Mario melody
Note superMarioNotes[] = {
    {NOTE_E4, 100}, {NOTE_E4, 100}, {NOTE_E4, 100},
    // ... other notes ...
};

// Define the melodies
Melody melodies[] = {
    {superMarioNotes, sizeof(superMarioNotes) / sizeof(Note),
     "Super Mario Theme"},
    // {otherMelodyNotes, sizeof(otherMelodyNotes) / sizeof(Note), "Other
    // Melody"},
};

Melody getMelody(MelodyName name) { return melodies[name]; }
