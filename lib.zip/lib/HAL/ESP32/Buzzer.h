#pragma once

#include <IBuzzer.h>

/**
 * @class Buzzer
 * @brief ESP32-specific implementation of the buzzer interface.
 * @details Non-blocking is acheived using a hardware timer.
 */