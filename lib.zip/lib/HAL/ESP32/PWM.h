#pragma once

#include <IPWM.h>

/**
 * @class PWM
 * @brief ESP32-specific implementation of the IPWM interface.
 *
 * This class provides the operations for PWM (Pulse Width Modulation) tailored
 * for the ESP32 platform.
 */
class PWM : public IPWM {
private:
  int _pinNumber;           ///< Pin number for PWM operations.
  double _dutyCycle;        ///< Current duty cycle (0.0 to 1.0).
  double _frequency;        ///< Current PWM frequency in Hertz.
  ConfigMap _configOptions; ///< Configuration options.

public:
  /**
   * @brief Construct a new PWM object for ESP32.
   *
   * @param pin The pin number for PWM operations.
   * @param frequency Initial frequency for PWM in Hertz.
   * @param options Additional configuration options for the pin.
   */
  PWM(int pin, double frequency, const ConfigMap &options = {});

  virtual void setDutyCycle(double dutyCycle) override;
  virtual double getDutyCycle() const override;
  virtual void setFrequency(double frequency) override;
  virtual double getFrequency() const override;
};
