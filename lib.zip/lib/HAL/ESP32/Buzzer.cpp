#ifdef PLATFORM_ESP32
#include <Arduino.h>

#endif // PLATFORM_ESP32