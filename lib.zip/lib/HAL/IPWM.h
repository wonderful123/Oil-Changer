#pragma once

#include <ComponentConfig.h>

/**
 * @class IPWM
 * @brief Interface for PWM (Pulse Width Modulation) operations.
 *
 * This interface provides the fundamental operations for controlling
 * PWM outputs, such as setting the duty cycle or frequency. Implementations
 * of this interface should provide platform-specific details for these
 * operations.
 */
class IPWM {
private:
  double _frequency;
  double _dutyCycle;
  ConfigMap _configOptions;

public:
  virtual ~IPWM() = default;

  /**
   * @brief Constructs the IPWM object.
   *
   * This method should be used to configure and initialize the PWM
   * pin with the specified frequency and any additional configuration options.
   *
   * @param frequency Frequency for PWM in Hertz.
   * @param options Additional configuration options for the pin.
   */
  IPWM(double frequency, const ConfigMap &options = {})
      : _frequency(frequency), _configOptions(options) {
    // Set pin mode for PWM and other configurations
    // ...
  }

  /**
   * @brief Set the duty cycle for the PWM.
   *
   * This method adjusts the pulse width of the PWM signal.
   *
   * @param dutyCycle Duty cycle for the PWM (0.0 to 1.0).
   */
  virtual void setDutyCycle(double dutyCycle) = 0;

  /**
   * @brief Get the current duty cycle of the PWM.
   *
   * This method retrieves the current duty cycle setting of the PWM.
   *
   * @return double Current duty cycle (0.0 to 1.0).
   */
  virtual double getDutyCycle() const = 0;

  /**
   * @brief Set the frequency for the PWM.
   *
   * This method sets the frequency of the PWM signal in Hertz.
   *
   * @param frequency Frequency for PWM in Hertz.
   */
  virtual void setFrequency(double frequency) = 0;

  /**
   * @brief Get the current frequency of the PWM.
   *
   * This method retrieves the current frequency setting of the PWM.
   *
   * @return double Current frequency in Hertz.
   */
  virtual double getFrequency() const = 0;
};
