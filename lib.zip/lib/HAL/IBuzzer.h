/* 
The Buzzer.h file should define an abstract class Buzzer that provides a common interface for buzzer operations. This class should be part of the HAL (Hardware Abstraction Layer) as it provides a hardware-agnostic interface for buzzer operations.

The Buzzer class should have the following methods:

- beep(int frequency, int duration): This method should start the buzzer with a specific frequency and duration. The implementation of this method should be non-blocking, meaning it should return immediately after starting the buzzer and not wait for the beep to finish.

- stop(): This method should stop the buzzer.

- update(): This method should be used to update the state of the buzzer when a software timer is used. If a hardware timer is used, this method does not need to be implemented.
*/

#pragma once

class Buzzer {
public:
  Buzzer() = default;
  virtual ~Buzzer() = default;

  virtual void beep(int frequency, int duration) = 0;

  virtual void stop() = 0;

  virtual void update() = 0;

};
