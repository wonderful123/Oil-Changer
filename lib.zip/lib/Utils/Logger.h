#pragma once

#include <functional>

class Logger {
public:
  using LogCallback = std::function<void(const char *)>;

private:
  static LogCallback log_callback;

public:
  static void setLogCallback(LogCallback callback);
  static void log(const char *message);
};