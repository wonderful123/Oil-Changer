#pragma once

#include "ErrorCodes.h"
#include "Logger.h"
#include <cstdio>

class Error {
private:
  ErrorCode code;

public:
  explicit Error(ErrorCode errorCode = ErrorCode::OK) : code(errorCode) {
    Logger::log(getFormattedMessage());
  }

  operator ErrorCode() const { return code; }

  std::string_view message() const { return GetErrorMessage(code); }

  const char *getFormattedMessage() const {
    static char formattedMessage[128];
    snprintf(formattedMessage, sizeof(formattedMessage), "Error Code: %d - %s",
             static_cast<int>(code), message().data());
    return formattedMessage;
  }
};
