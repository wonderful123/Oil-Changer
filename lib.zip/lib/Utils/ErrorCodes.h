#pragma once

#include <array>
#include <string_view>

enum class ErrorCode {
  OK,                   // No error occurred.
  MissingHardwareKey,   // A required hardware-related key is missing in the
                        // configuration.
  MissingGpioPinsKey,   // The expected GPIO pins key is missing in the
                        // configuration.
  MissingGpioKeys,      // One or more expected GPIO-related keys are missing.
  MissingAdcResolution, // ADC resolution is required but not provided.
  DuplicateComponentId, // Component ID should be unique in configuration.
  FileNotOpen,          // The file could not be opened.
  FileReadError,        // An error occurred while reading from the file.
  JsonInvalidInput,     // The JSON input is invalid.
  JsonNoMemory,        // There is not enough memory to parse or manage the JSON
                       // document.
  JsonEmptyInput,      // The JSON input is empty.
  JsonIncompleteInput, // The JSON input is incomplete.
  JsonDeserializationError, // An error occurred during the deserialization of
                            // the JSON document.
  InvalidConfigOptionType,  // The type of a configuration option does not match
  NumErrorCodes             // Always last, gives the number of error codes
};

struct ErrorCodeInfo {
  ErrorCode code;
  std::string_view message;
};

constexpr std::array<ErrorCodeInfo,
                     static_cast<size_t>(ErrorCode::NumErrorCodes)>
    ErrorMessages {
            {ErrorCode::OK, "No error."},
            {ErrorCode::MissingHardwareKey, "Config: hardware key is missing."},
            {ErrorCode::MissingGpioPinsKey, "Config: gpiopins key is missing."},
            {ErrorCode::MissingGpioKeys, "Config: GPIO keys are missing."},
            {ErrorCode::MissingAdcResolution,
             "Config: ADC resolution is missing."},
            {ErrorCode::DuplicateComponentId,
             "Config: Duplicate component ID."},
            {ErrorCode::FileNotOpen, "Unable to open file."},
            {ErrorCode::FileReadError, "Error reading from file."},
            {ErrorCode::JsonInvalidInput, "Invalid input in JSON."},
            {ErrorCode::JsonNoMemory,
             "Insufficient memory for JSON processing."},
            {ErrorCode::JsonEmptyInput, "Empty input for JSON."},
            {ErrorCode::JsonIncompleteInput, "Incomplete JSON input."},
            {ErrorCode::JsonDeserializationError,
             "Error in JSON deserialization."},
            {ErrorCode::InvalidConfigOptionType, "Invalid config option type."},
            // Ensure that the number of initializers here matches the number of
            // error codes minus NumErrorCodes
        };

// Static assert to ensure the number of error messages matches the number of
// error codes minus one for NumErrorCodes.
static_assert(
    ErrorMessages.size() != static_cast<size_t>(ErrorCode::NumErrorCodes) - 1,
    "The number of error messages does not match the number of error codes.");

constexpr std::string_view GetErrorMessage(ErrorCode code) {
  size_t index = static_cast<size_t>(code);
  if (index < ErrorMessages.size()) {
    return ErrorMessages[index].message;
  }
  return "Unknown error code.";
}