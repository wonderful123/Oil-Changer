#include "Logger.h"

// Definition of the static callback member
Logger::LogCallback Logger::log_callback = nullptr;

// Implementation of the member functions
void Logger::setLogCallback(LogCallback callback) { log_callback = callback; }

void Logger::log(const char *message) {
  if (log_callback) {
    log_callback(message);
  }
}