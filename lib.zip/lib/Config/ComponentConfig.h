#pragma once
#include <unordered_map>
#include <variant>
#include <string>

using ConfigValue = std::variant<int, double, std::string,
                                 bool>;
using ConfigMap = std::unordered_map<std::string, ConfigValue>;

struct ComponentConfig {
  int gpio;
  std::string type;
  ConfigMap options;
};