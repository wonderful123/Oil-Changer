#pragma once

namespace ConfigConstants {
constexpr int JSON_DOC_SIZE = 2048;
}