#include "Config.h"
#include "ConfigValidator.h"
#include "JsonDeserializer.h"

Error Config::load(const std::string &path) {
  FileGuard fileGuard(_fileHandler, path);
  if (!fileGuard.isOpen()) {
    return Error(ErrorCode::FileNotOpen);
  }

  std::string fileContent = fileGuard.read();
  if (fileContent.empty()) {
    return Error(ErrorCode::FileReadError);
  }

  DeserializationError jsonError = deserializeJson(_doc, fileContent);
  if (jsonError) {
    return Error(ErrorCode::JsonDeserializationError);
  }

  Error validationError = ConfigValidator::validateConfiguration(_doc);
  if (validationError != ErrorCode::OK) {
    return validationError;
  }

  Error populateError = populateComponentConfigs();
  return populateError; // Return any errors from populating the configuration
}

Error Config::populateComponentConfigs() {
  JsonArray gpioPins = _doc["gpioPins"].as<JsonArray>();

  for (JsonObject pinConfig : gpioPins) {
    ComponentConfig componentConfig;
    componentConfig.gpio = pinConfig["gpio"].as<int>();
    componentConfig.type = pinConfig["type"].as<std::string>();

    JsonObject options = pinConfig["options"].as<JsonObject>();
    for (JsonPair kv : options) {
      ConfigValue value;

      if (kv.value().is<int>()) {
        value = kv.value().as<int>();
      } else if (kv.value().is<double>()) {
        value = kv.value().as<double>();
      } else if (kv.value().is<bool>()) {
        value = kv.value().as<bool>();
      } else if (kv.value().is<const char *>()) {
        value = kv.value().as<std::string>();
      } else {
        return Error(ErrorCode::InvalidConfigOptionType);
      }
      componentConfig.options[kv.key().c_str()] = std::move(value);
    }

    auto result = _componentsConfig.emplace(pinConfig["id"].as<std::string>(),
                                            std::move(componentConfig));
    if (!result.second) {
      // The emplace failed because the key already exists
      return Error(ErrorCode::DuplicateComponentId);
    }
  }
  return Error(ErrorCode::OK);
}

std::optional<ComponentConfig>
Config::getConfigFor(const std::string &componentId) const {
  auto it = _componentsConfig.find(componentId);
  if (it != _componentsConfig.end()) {
    return it->second;
  }
  return std::nullopt; // No match found, return an empty optional.
}
