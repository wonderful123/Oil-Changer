#pragma once

#include "ComponentConfig.h"
#include "Error.h"  // This should include ErrorCodes.h
#include <optional> // Make sure to include this
#include <string>

class Config {
public:
  explicit Config(IFileHandler *fileHandler) : _fileHandler(fileHandler) {}

  Error load(const std::string &path);

  std::optional<ComponentConfig>
  getConfigFor(const std::string &componentId) const;

private:
  ArduinoJson::StaticJsonDocument<ConfigConstants::JSON_DOC_SIZE> _doc;
  std::unordered_map<std::string, ComponentConfig>
      _componentsConfig; // Keyed by component ID
  IFileHandler *_fileHandler;

  Error populateComponentConfigs();
};