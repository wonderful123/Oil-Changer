#include "ConfigValidator.h"

namespace ConfigValidator {

// Helper function to check the presence of main keys in the JSON document.
Error checkMainKeys(const ArduinoJson::StaticJsonDocument<JSON_DOC_SIZE> &doc) {
  if (!doc.containsKey("hardware")) {
    return Error(ErrorCode::MissingHardwareKey);
  }
  if (!doc.containsKey("gpioPins")) {
    return Error(ErrorCode::MissingGpioPinsKey);
  }
  return Error(ErrorCode::OK);
}

// Helper function to check mandatory keys within "gpioPins" section.
Error checkGpioPinKeys(
    const ArduinoJson::StaticJsonDocument<JSON_DOC_SIZE> &doc) {
  if (!doc.containsKey("gpioPins") || !doc["gpioPins"].is<JsonArray>()) {
    return Error(ErrorCode::MissingGpioKeys);
  }

  for (const JsonObjectConst &gpioPin : doc["gpioPins"].as<JsonArrayConst>()) {
    if (!gpioPin.containsKey("gpio") || !gpioPin.containsKey("type") ||
        !gpioPin["gpio"].is<int>()) {
      return Error(ErrorCode::MissingGpioKeys);
    }
    if (gpioPin["type"].as<std::string>() == "ADC" &&
        !gpioPin.containsKey("resolution")) {
      return Error(ErrorCode::MissingAdcResolution);
    }
  }
  return Error(ErrorCode::OK);
}

// Main validation function that uses the helper functions.
Error validateConfiguration(
    const ArduinoJson::StaticJsonDocument<JSON_DOC_SIZE> &doc) {
  Error error = checkMainKeys(doc);
  if (error == ErrorCode::OK) {
    error = checkGpioPinKeys(doc);
  }
  return error;
}

} // namespace ConfigValidator
