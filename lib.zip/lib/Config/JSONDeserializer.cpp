#include "JsonDeserializer.h"

ArduinoJson::StaticJsonDocument<ConfigConstants::JSON_DOC_SIZE>
JsonDeserializer::deserialize(const std::string &content, Error &error) {
  ArduinoJson::StaticJsonDocument<ConfigConstants::JSON_DOC_SIZE> doc;
  auto deserializationError = ArduinoJson::deserializeJson(doc, content);

  if (deserializationError) {
    // Map ArduinoJson's DeserializationError to your ErrorCode enum
    switch (deserializationError.code()) {
    case ArduinoJson::DeserializationError::InvalidInput:
      error = Error(ErrorCode::JsonInvalidInput);
      break;
    case ArduinoJson::DeserializationError::NoMemory:
      error = Error(ErrorCode::JsonNoMemory);
      break;
    case ArduinoJson::DeserializationError::EmptyInput:
      error = Error(ErrorCode::JsonEmptyInput);
      break;
    case ArduinoJson::DeserializationError::IncompleteInput:
      error = Error(ErrorCode::JsonIncompleteInput);
      break;
    default:
      error = Error(ErrorCode::JsonDeserializationError);
      break;
    }
    return {}; // Return an empty document to signal a failure
  }
  return doc; // Return the populated document on success
}
