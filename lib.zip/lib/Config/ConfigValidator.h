#pragma once

#include "ConfigConstants.h"
#include "Error.h"
#include <ArduinoJson.h>

namespace ConfigValidator {

using namespace ConfigConstants;

// Validate the entire configuration.
Error validateConfiguration(
    const ArduinoJson::StaticJsonDocument<JSON_DOC_SIZE> &doc);

} // namespace ConfigValidator
